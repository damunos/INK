// src/components/SignIn.jsx
import React from "react";

const SignIn = () => {
  return (
    <div>
      <h1>Sign In</h1>
      <p>Sign In page placeholder. Implement your form here.</p>
    </div>
  );
};

export default SignIn;
