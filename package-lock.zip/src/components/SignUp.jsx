// src/components/SignUp.jsx
import React from "react";

const SignUp = () => {
  return (
    <div>
      <h1>Sign Up</h1>
      <p>Sign Up page placeholder. Implement your form here.</p>
    </div>
  );
};

export default SignUp;
