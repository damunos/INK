// src/components/UserProfile.jsx
import React from "react";

const UserProfile = () => {
  return (
    <div>
      <h1>User Profile</h1>
      <p>User Profile page placeholder. Display user information here.</p>
    </div>
  );
};

export default UserProfile;
