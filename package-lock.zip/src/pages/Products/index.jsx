// src/pages/Products/index.jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './Products.css';

const Products = () => {
  const [productData, setProductData] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      try {
        const response = await axios.post('http://localhost:3001/api/promostandards/products', {
          wsdlUrl: 'https://test-ws.sanmar.com:8080/promostandards/ProductDataServiceBinding?WSDL',
          username: 'melaniesue9972',
          password: 'Alan1963!',
          productId: 'EXAMPLE_PRODUCT_ID',
        });

        setProductData(response.data);
      } catch (error) {
        console.error('Error fetching product data:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, []);

  return (
    <div>
      <h2>SanMar Product Data</h2>
      {loading && <p>Loading...</p>}
      {productData ? (
        <pre>{JSON.stringify(productData, null, 2)}</pre>
      ) : (
        !loading && <p>No data loaded yet.</p>
      )}
    </div>
  );
};

export default Products;
